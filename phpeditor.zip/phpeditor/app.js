$(document).ready(function(){
	

	var code = $(".codemirror-textarea")[0];
    var editor = CodeMirror.fromTextArea(code, {
        mode: "application/x-httpd-php",
        lineNumbers: true,
        matchBrackets: true,
        theme: "ambiance",
        lineWiseCopyCut: true,
        undoDepth: 200
      });



	$(document).on('click', '#run', function(e){
		e.preventDefault();
		var input = editor.getValue();
		//console.log(input);
		if(input == ''){
			alert('Please enter the code!');
		}else{
		$.ajax({
			url: 'controller.php',
			type: 'POST',
			dataType: 'json',
			data: {"input":input},
			success:function(response){
			
			},
			complete:function(){
				$.ajax({
					url: 'test.php',
					type: 'GET',
					success:function(response){
						console.log("response:  "+response);
						var response = response.replace('C:\\xamppp\\htdocs\\phpeditor\\test.php','demo_code');
						$("#result").html(response)	;
					},
					error:function(){
						console.log("error: "+response);
					}
				});	
			}
		});
	}

	});

	$(document).on('click', '#clear', function(e){
		e.preventDefault();
		editor.setValue('');
	});


	$(document).on('click', '#refresh', function(e){
		e.preventDefault();
		//editor.refresh();
		location.reload();
		
	});

var demo_code = function(){
		editor.setValue('<?php\necho "Hello!!!"\n?>');
		$('#run').trigger('click');
}	

demo_code();




});