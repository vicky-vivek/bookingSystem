<!DOCTYPE html>
<html>
<head>
	<title>Editor</title>
	
    <link rel="stylesheet" type="text/css" href="lib/codemirror/lib/codemirror.css">
    <link rel="stylesheet" type="text/css" href="lib/codemirror/theme/ambiance.css">
    <script src="lib/jQuery/jQuery.js"></script>
    <script src="lib/codemirror/lib/codemirror.js"></script>
  	<link rel="stylesheet" type="text/css" href="styles.css">
  	<script src="app.js"></script>
    <script src="lib/codemirror/mode/htmlmixed/htmlmixed.js"></script>
    <script src="lib/codemirror/mode/xml/xml.js"></script>
    <script src="lib/codemirror/mode/javascript/javascript.js"></script>
    <script src="lib/codemirror/mode/css/css.js"></script>
    <script src="lib/codemirror/mode/clike/clike.js"></script>
    <script src='lib/codemirror/mode/php/php.js'></script>
    <script src='lib/codemirror/addon/selection/active-line.js'></script>
    <script src='lib/codemirror/addon/edit/matchbrackets.js'></script>

</head>
<body>
<div class="row">
	<textarea class="codemirror-textarea" id="ed_code"></textarea>
  <br/>
  <button id="run">Run</button>
  <button id="clear">Clear</button>
  <button id="refresh">Refresh</button>
</div>
<div class="row">	
  <br/>
  <div id="result"></div>
</div>	
    
</body>
</html> 



