$(document).ready(function(){
	

	var code = $(".codemirror-textarea")[0];
    var editor = CodeMirror.fromTextArea(code, {
        lineNumbers: true,
        matchBrackets: true
      });



	$(document).on('click', '#run', function(e){
		e.preventDefault();
		var input = editor.getValue();
		//console.log(input);
		if(input == ''){
			alert('NA');
		}else{
		$.ajax({
			url: 'controller.php',
			type: 'POST',
			dataType: 'json',
			data: {"input":input},
			success:function(response){
			
			},
			complete:function(){
				$.ajax({
					url: 'test.php',
					type: 'GET',
					success:function(response){
						console.log("response:  "+response);
						$("#result").html(response)	;
					},
					error:function(){
						console.log("error: "+response);
					}
				});	
			}
		});
	}

	});


});