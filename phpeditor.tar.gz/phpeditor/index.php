<!DOCTYPE html>
<html>
<head>
	<title>Editor</title>
	
    <link rel="stylesheet" type="text/css" href="lib/codemirror/lib/codemirror.css">
    <script src="lib/jQuery/jQuery.js"></script>
    <script src="lib/codemirror/lib/codemirror.js"></script>
  	<link rel="stylesheet" type="text/css" href="styles.css">
  	<script src="app.js"></script>

</head>
<body>
<div class="row">
	<textarea class="codemirror-textarea" id="ed_code"></textarea>
    <button id="run">Run</button>
</div>
<div class="row">	
    <div id="result"></div>
</div>	
    
</body>
</html> 



